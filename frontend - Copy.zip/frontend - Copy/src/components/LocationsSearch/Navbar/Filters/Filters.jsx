import './Filters.css'

const Filters = () => {
  return (
    <div>Filters</div>
  )
}

export default Filters