const Title = ({title}) => {
  return (
    <div className="trips_title">{title}</div>
  )
}

export default Title